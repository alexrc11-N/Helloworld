/*********************
* Your comment header here.
**********************/

#ifndef COMMANDLINE_MAIN_H
#define COMMANDLINE_MAIN_H

#include <iostream>


using std::cout;
using std::endl;

#endif //COMMANDLINE_MAIN_H
