/*****************
*I Hope this works :)
***********************/

#ifndef COMMANDLINE_FUNCTIONS_H
#define COMMANDLINE_FUNCTIONS_H

int string_length(const char*);


#endif // COMMANDLINE_FUNCTIONS_H
