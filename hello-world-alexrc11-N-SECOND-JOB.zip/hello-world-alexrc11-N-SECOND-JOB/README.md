my first C++ program in data structures class

